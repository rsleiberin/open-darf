{
  "system": {
    "gpu_name": "NA",
    "driver": "NA",
    "cuda_driver": "NA",
    "torch_version": "not_installed",
    "torch_cuda": null
  },
  "timing": {
    "p50_ms": null,
    "p95_ms": null,
    "n_iters": 0
  },
  "result": {
    "passed": false,
    "reason": "torch not installed"
  },
  "artifact_hash": null
}
