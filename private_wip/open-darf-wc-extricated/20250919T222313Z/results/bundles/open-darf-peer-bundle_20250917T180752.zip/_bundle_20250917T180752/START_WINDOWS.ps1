Write-Host "=== Open-DARF · Start (Windows) ==="
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\run.ps1
