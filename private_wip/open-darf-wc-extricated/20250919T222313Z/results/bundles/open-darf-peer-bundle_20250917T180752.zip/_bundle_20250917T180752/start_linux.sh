#!/usr/bin/env bash
set -euo pipefail
printf "===\n===\n===\n"
echo "=== Open-DARF · Start (Linux) ==="
bash ./scripts/run.sh
